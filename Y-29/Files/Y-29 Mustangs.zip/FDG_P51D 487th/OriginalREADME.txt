Greetings !
And thanks for taking the time to download one of our free add ons !

There are some great ideas behind the Fightertown Design Group, one of the main ones is the limited rules for usage of our groups files. 
They're real simple to remember:
1.  Keep this file "OriginalReadMe.txt" with anything you do with one of the files contained in this package.
2.  If you do make any modifications, repaints, etc of one of our planes, please change the aircraft title in the aircraft.cfg to eliminate confusion.
  
That's it! You dont need to ask for permission or get special authorization!  Just keep this file with anything you do and thats it :) The idea is Free, real, and with not too many strings attached! LOL 

Theres gotta be one :) for designers just starting out:
These files are a great way to get started and thats part of the idea.  
All FSDS source files can be found on our FDG site.  
The only limitation is this OriginalReadMe.txt.  Real simple and we hope, great fun!


Fightertown Design Group:
http://www.fightertown.tv
http://www.fightertown.tv/FDG_1.htm

Please visit our site, and leave a message on the Board.  Tell us what ya think, see who we are, or just say howdy. :)


Very Limited Copyright :)
These files have been created by the FDG for the free use and enjoyment of anyone with the limitations stated above.  We at the FDG dont claim to be the best, well maybe we are:)




Current FDG Staff:

Bill "Razor" Ross
Scott "Jinkers" Flugum
"Mopar" Mike Wagner
Larry Vrooman
Kep "KAP" Procell
Kevin Bacon
T. "m18hellcat" Reid
Dan "Dswart" Swart
Dan "Tomahawk6" Goodwin
marvh


